function Global.GetTrainCarriageIndex(train)
	return _in(0x4b8285cf, train, _ri)
end
