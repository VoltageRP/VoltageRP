function Global.GetBlipSprite(self)
	return _in(0x72ff2e73, self, _ri)
end
