--- A getter for [SET_RESOURCE_KVP](#\_0x21C7A35B).
-- @param key The key to fetch
-- @return A string that contains the value stored in the Kvp or nil/null if none.
function Global.GetResourceKvpString(key)
	return _in(0x5240da5a, _ts(key), _s)
end
