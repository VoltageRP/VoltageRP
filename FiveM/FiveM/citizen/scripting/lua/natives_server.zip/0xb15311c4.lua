function Global.NetworkGetVoiceProximityOverride(playerSrc)
	return _in(0x7a6462f4, _ts(playerSrc), _rv)
end
