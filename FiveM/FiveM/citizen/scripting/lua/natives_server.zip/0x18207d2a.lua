--- Seat indexes:
-- *   1 = Driver
-- *   2 = Front Right Passenger
-- *   3 = Back Left Passenger
-- *   4 = Back Right Passenger
-- *   5 = Further Back Left Passenger (vehicles > 4 seats)
-- *   6 = Further Back Right Passenger (vehicles > 4 seats)
-- *   etc.
-- @param vehicle The target vehicle.
-- @param index The seat index.
-- @return The ped in the specified seat of the passed vehicle. Returns 0 if the specified seat is not occupied.
function Global.GetPedInVehicleSeat(vehicle, index)
	return _in(0x388fde9a, vehicle, index, _ri)
end
