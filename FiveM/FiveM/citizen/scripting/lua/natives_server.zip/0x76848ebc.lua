function Global.GetResourceByFindIndex(findIndex)
	return _in(0x387246b7, findIndex, _s)
end
