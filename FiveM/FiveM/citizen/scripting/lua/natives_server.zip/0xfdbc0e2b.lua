function Global.GetAirDragMultiplierForPlayersVehicle(playerSrc)
	return _in(0x62fc38d0, _ts(playerSrc), _rf)
end
