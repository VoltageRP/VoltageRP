--- Seat indexes:
-- *   1 = Driver
-- *   2 = Front Right Passenger
-- *   3 = Back Left Passenger
-- *   4 = Back Right Passenger
-- *   5 = Further Back Left Passenger (vehicles > 4 seats)
-- *   6 = Further Back Right Passenger (vehicles > 4 seats)
-- *   etc.
-- @param vehicle The target vehicle.
-- @param index The seat index.
-- @return The last ped in the specified seat of the passed vehicle. Returns 0 if the specified seat was never occupied or the last ped does not exist anymore.
function Global.GetLastPedInVehicleSeat(vehicle, index)
	return _in(0xf7c6792d, vehicle, index, _ri)
end
