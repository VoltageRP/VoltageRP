function Global.GetPedDesiredHeading(ped)
	return _in(0xc182f76e, ped, _rf)
end
