function Global.ClearPedTasks(ped)
	return _in(0xde3316ab, ped)
end
