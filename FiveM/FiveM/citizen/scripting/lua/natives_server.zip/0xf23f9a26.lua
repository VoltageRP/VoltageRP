--- List of component/props ID
-- gtaxscripting.blogspot.com/2016/04/gta-v-peds-component-and-props.html
function Global.ClearPedProp(ped, propId)
	return _in(0x2d23d743, ped, propId)
end
