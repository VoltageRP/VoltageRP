--- Set the model for a specific Player. Be aware that this will destroy the current Ped for the Player and create a new one, any reference to the old ped should be reset
-- Make sure to request the model first and wait until it has loaded.
function Global.SetPlayerModel(player, model)
	return _in(0x774a4c54, _ts(player), _ch(model))
end
